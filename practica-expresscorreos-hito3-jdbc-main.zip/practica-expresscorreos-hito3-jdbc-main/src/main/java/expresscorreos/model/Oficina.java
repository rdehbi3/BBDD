package expresscorreos.model;

public class Oficina {
    private String código_oficina;
    private String nombre_municipio;
    private String codigo_cc;

    public Oficina(String código_oficina, String nombre_municipio, String codigo_cc) {
        this.código_oficina = código_oficina;
        this.nombre_municipio = nombre_municipio;
        this.codigo_cc = codigo_cc;
    }

    public String getCódigo_oficina() {
        return código_oficina;
    }

    public String getNombre_municipio() {
        return nombre_municipio;
    }

    public String getCodigo_cc() {
        return codigo_cc;
    }
}
