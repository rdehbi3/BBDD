import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import expresscorreos.model.Cartero;
import expresscorreos.model.Coche;
import expresscorreos.model.Oficina;

public class Main {
    // @TODO: Sustituya xxxx por los parámetros de su conexión

    private static final String DB_SERVER = "127.0.0.1";

    private static final int DB_PORT = 3306;

    private static final String DB_NAME = "EXPRESS_CORREOS";

    private static final String DB_USER = "root";

    private static final String DB_PASS = "";

    private static Connection conn;

    public static void main(String[] args) throws Exception {

        Class.forName("com.mysql.cj.jdbc.Driver");

        String url = "jdbc:mysql://" + DB_SERVER + ":" + DB_PORT + "/" + DB_NAME;
        conn = DriverManager.getConnection(url, DB_USER, DB_PASS);
        /*1.
                nuevoCartero("12345679D", "Pepito", "Manuel");*/

        /*2.
        ArrayList<Oficina> ofis = oficinasAsociadasCalle("Alcalá de Madrid");
        System.out.println("ofi size"+ofis.size());
            System.out.println(ofis.get(i).getCódigo_oficina() + " "+ofis.get(i).getNombre_municipio());
            System.out.println("hola");*/
        /*3
        int i = 0;
        ArrayList<Cartero> carteros = carterosRepartoCochePeriodo(7);
        System.out.println("ofi size" + carteros.size());


        while (i < carteros.size()) {
            System.out.println(carteros.get(i).getNombre() + " " + carteros.get(i).getDNI());
            i++;
        }*/
        ArrayList<Coche> coches = cochesSinUtilizarPeriodo(30); int i = 0;
        System.out.println("coche size" + coches.size());
        while (i < coches.size()) {
            System.out.println(coches.get(i).getMatricula() + " " + coches.get(i).getCapacidad());
            i++;
        }

        // @TODO pruebe sus funciones

        conn.close();
    }

    // @TODO resuelva las siguientes funciones...
    // FALTA EN LA 2,3 implementarlo segun el atributo pero lo primero es que funcionen xD

    public static void nuevoCartero(String DNI, String nombre, String apellidos) { //Funciona
        PreparedStatement smnt;
        int rs;
        try {
            smnt = conn.prepareStatement("INSERT cartero (dni_cartero, nombre_cartero, apellidos_cartero) VALUES (?,?,?)");
            smnt.setString(1, DNI);
            smnt.setString(2, nombre);
            smnt.setString(3, apellidos);
            rs = smnt.executeUpdate();
            System.out.println(rs);
            smnt.close();
        } catch (SQLException sql) {

        }


    }

    public static ArrayList<Cartero> carterosRepartoCochePeriodo(int periodo) {
        // @TODO: complete este método para que muestre por pantalla una lista de carteros que han
        // realizado un reparto con coche en el periodo comprendido por los últimos "periodo" días
        // (implementar para periodo=7)
        // Tenga en cuenta que la consulta a la base de datos le devolverá un ResultSet sobre el que deberá
        // ir iterando y creando un objeto con cada Cartero que cumpla con las condiciones,
        // y añadirlos a la lista
        ArrayList<Cartero> listaCarterosRepartoCoche = new ArrayList<Cartero>();

        Statement smnt;
        ResultSet rs;
        try {
            smnt = conn.createStatement();
            rs = smnt.executeQuery("SELECT  DISTINCT cartero.dni_cartero, nombre_cartero, apellidos_cartero\n" +
                    "FROM cartero INNER JOIN trabaja ON trabaja.dni_cartero = cartero.dni_cartero\n" +
                    "             INNER JOIN reparto ON reparto.dni_cartero = cartero.dni_cartero\n" +
                    "             INNER JOIN coche ON trabaja.codigo_oficina = trabaja.codigo_oficina\n" +
                    "WHERE CURDATE()-reparto.fecha_reparto<=7 ;       ");

            while (rs.next()) {
                Cartero carteroNuevo = new Cartero(rs.getString("dni_cartero"), rs.getString("nombre_cartero"), rs.getString("apellidos_cartero"));
                listaCarterosRepartoCoche.add(carteroNuevo);
            }
        } catch (SQLException sql) {


        }
        return listaCarterosRepartoCoche;
    }

    public static ArrayList<Oficina> oficinasAsociadasCalle(String calle) {
        // @TODO: complete este método para que muestre por pantalla una lista de las oficinas que
        // dan servicio a la C/Alcalá de Madrid.
        // Tenga en cuenta que la consulta a la base de datos le devolverá un ResultSet sobre el que deberá
        // ir iterando y creando un objeto con cada Oficina que tenga asociada algún segmento de esa calle,
        // y añadirlos a la lista
        ArrayList<Oficina> listaOfisAlcala = new ArrayList<Oficina>();
        Statement smnt;
        ResultSet rs;
        try {

            smnt = conn.createStatement();
            rs = smnt.executeQuery("SELECT area_envio.codigo_oficina, oficina.nombre_municipio, oficina.codigo_cc\n" +
                    "FROM area_envio INNER JOIN oficina ON oficina.codigo_oficina = area_envio.codigo_oficina\n" +
                    "                INNER JOIN segmento ON area_envio.id_area = segmento.id_area\n" +
                    "                INNER JOIN calle ON segmento.nombre_calle = calle.nombre_calle\n" +
                    " GROUP BY area_envio.codigo_oficina, calle.nombre_calle\n" +
                    " HAVING nombre_calle = \"Alcalá de Madrid\";");
            System.out.println("Rows" + rs.getFetchSize());


            while (rs.next()) {
                Oficina ofi = new Oficina(rs.getString("codigo_oficina"), rs.getString("nombre_municipio"), rs.getString("codigo_cc"));
                listaOfisAlcala.add(ofi);
            }
        } catch (SQLException sql) {

        }

        return listaOfisAlcala;
    }

    public static ArrayList<Coche> cochesSinUtilizarPeriodo(int periodo) {
        // @TODO: complete este método para que muestre por pantalla una lista de los coches que no se han
        // utilizado en los últimos "periodo" días (implementar para periodo=30)

        ArrayList<Coche> listaOfCochesNoUsados = new ArrayList<Coche>();
        Statement smnt;
        ResultSet rs;
        try {

            smnt = conn.createStatement();
            rs = smnt.executeQuery("SELECT coche.matricula, capacidad, codigo_oficina\n" +
                    "FROM coche INNER JOIN reparto ON coche.matricula = reparto.matricula\n" +
                    "WHERE NOT CURDATE()-reparto.fecha_reparto<=30;  ");

            while (rs.next()) {
                Coche cocheAux = new Coche(rs.getString("matricula"),rs.getDouble("capacidad"),rs.getString("codigo_oficina"));
                listaOfCochesNoUsados.add(cocheAux);
            }
        } catch (SQLException sql) {

        }


        return listaOfCochesNoUsados;
    }

    }

